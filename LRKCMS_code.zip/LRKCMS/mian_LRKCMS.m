%% LRKLSG_mian
clc
clear
close all
addpath('.\function');
addpath('.\data');

%%
dataset = {'MSRCV1'}

%%
for ii = 1:length(dataset)
    load(dataset{ii})
    V = length(X);% feature*sample
    for i = 1:V
        X{i} = X{i}';
    end
    true_label = Y;
    nCluster = length(unique(true_label));
    lambda1 = 0.05;
    lambda2 = 0.03;
    lambda3 = 0.5;
    kType = 'pol';
    param.a = 11;
    param.b = 2;
    param.p = 0.9;
    param.maxIter = 30;
    tic
    Zn = LRKCMS_opt(X, lambda1, lambda2, lambda3, kType, param);
    M = retain(Zn);
    W = postprocessor(M);
    result_label = new_spectral_clustering(W,nCluster);
    disp('ACC NMI Fscore Precision ARI Purity Recall Entropy')
    result(ii,:) = Clustering8Measure(true_label, result_label)
    time(ii) = toc;
end
