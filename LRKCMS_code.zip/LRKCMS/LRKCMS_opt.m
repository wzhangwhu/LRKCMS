function Zn = LRKCMS_opt(X, lambda1, lambda2, lambda3, kType, param)
V = length(X);
for i = 1:size(X,2)
    X{i} = X{i}./(repmat(sqrt(sum(X{i}.^2,1)),size(X{i},1),1)+eps);
end
[~, N] = size(X{1});

%% Construct the kernel function
for i = 1:V
    if(strcmpi(kType,'pol'))
        a = param.a;
        b = param.b;
        KG{i} = polynKernelMatrix(X{i},a,b);
    elseif(strcmpi(kType,'lin'))
        KG{i} = polynKernelMatrix(X{i},0,1);
    elseif(strcmpi(kType,'rbf'))
        sig = std(sqrt(sum(X{i}.^2)));
        KG{i} = rbfKernelMatrix(X{i}, 1*sig);
    else
        disp(['Select the kernel types: pol, lin, or rbf! Pol is used by default.']);
        KG{i} = polynKernelMatrix(X{i},1.4,3);
    end
end

%% ADMM parameters
p = param.p;
rho = 2.7;
miu = 0.01;
miu_max = 1e8;
maxIter = param.maxIter;

%% Initializations
for i = 1:V
    [U,S,VV] = svd(KG{i});
    B{i} = U*sqrt(S)*VV';
    C = zeros(N,N);
    Z{i} = zeros(N, N);
    J{i} = zeros(N, N);
    L{i} = zeros(N, N);
    R{i} = zeros(N, N);
    E{i} = zeros(N, N);
    Q1{i} = zeros(N, N);
    Q2{i} = zeros(N, N);
    Q3{i} = zeros(N, N);
end

%% Iter
iter = 0;
while(iter<maxIter)
    iter = iter+1;
    tempC = zeros(N,N);
    for v = 1:V
        %% ------------------- Update E ---------------------------------
        tempE = KG{v} - B{v}'*B{v} + Q3{v}/miu;
        for i = 1:N
            nw = norm(tempE(:,i));
            if nw > lambda3/miu
                x = (nw-lambda3/miu)*tempE(:,i)/nw;
            else
                x = zeros(length(tempE(:,i)),1);
            end
            tempE(:,i) = x;
        end
        E{v} = tempE;
        
        %% ------------------- Update L and R ---------------------------------
        tempL = (Q1{v}/miu+Z{v})*R{v}*C';
        [u,~,vv] = svd(tempL,'econ');
        L{v} = u*vv';
        tempR = (Q1{v}/miu+Z{v})'*L{v}*C;
        [u,~,vv] = svd(tempR,'econ');
        R{v} = u*vv';
        
        %% ------------------- Update Z ---------------------------------
        M1 = L{v}*C*R{v}' - Q1{v}/miu;
        M2 = J{v} - Q2{v}/miu;
        tempZ = 2*lambda2*B{v}'*B{v} + miu*M1 + miu*M2;
        Z{v} = (2*lambda2*B{v}'*B{v} + 2*miu*eye(N))\tempZ;
        
        %% ------------------- Update B ---------------------------------
        tempB = KG{v} - E{v} - (lambda2*(eye(N)-2*Z{v}+Z{v}*Z{v}')-Q3{v})/miu;
        B{i} = solveB(tempB, miu/lambda1);
        
        %% ------------------- Update J ---------------------------------
        tempJ = Z{v} + Q2{v}/miu;
        J{v} = (tempJ + tempJ')/2;
        tempC = tempC + L{v}'*(Q1{v}/miu+Z{v})*R{v};
        
    end
    %% ------------------- Update C ---------------------------------
    [UUU,sigma,VVV] = svd(tempC/V,'econ');
    sigma = diag(sigma);
    xi = spw(sigma,1/(V*miu),p);
    C = UUU*diag(xi)*VVV';
    
    %% ------------------- Update Q1,Q2,Q3 and miu ------------------
    for v = 1:V
        tempQ1 = Z{v}-L{v}*C*R{v}';
        tempQ2 = Z{v}-J{v};
        tempQ3 = KG{v}-B{v}'*B{v}-E{v};
        Q1{v} = Q1{v}+miu*tempQ1;
        Q2{v} = Q2{v}+miu*tempQ2;
        Q3{v} = Q3{v}+miu*tempQ3;
    end
    miu = min(rho*miu,miu_max);
    
    %% ----------------------- Stop ---------------------------------
    for v=1:V
        tempstop = Z{v}-L{v}*C*R{v}';
        temp_ter1(v) = max(max(abs(tempstop)));
    end
    stop = max(temp_ter1);
    disp(['iter' num2str(iter) 'stop' num2str(stop)])
    if abs(stop)<0.01
        break
    end
    
end
%%
Zn = zeros(N, N);
for v = 1 : V
    Zn = Zn + Z{v};
end
end